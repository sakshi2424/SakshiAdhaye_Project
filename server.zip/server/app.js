const express = require('express')
const bodyParser = require('body-parser')

const app = express()

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var cars = [
    {
        id:1,
        make:"abc",
        color: "red",
        price: 10000000
    },
    {
        id:2,
        make:"abc",
        color: "red",
        price: 10000000
    },
    {
        id:3,
        make:"abc",
        color: "red",
        price: 10000000
    },
    {
        id:4,
        make:"abc",
        color: "red",
        price: 10000000
    }
]

app.get("/cars", (req, res) => {
    res.send(cars)
})

app.post("/cars", (req, res) => {
    const id = req.body.id
    const make = req.body.make
    const color = req.body.color
    const price = req.body.price

    cars.push({id:id, make:make, color:color, price:price})
    res.send("Car added succesfully")
})



app.listen(3000, () => {
    console.log("listning on 3000.");
})